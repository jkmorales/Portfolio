<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-4 col-md-offset-4" style="opacity: .75;">
            <div class="panel panel-default">

                <div class="panel-body">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group" <?php echo e($errors->has('email') ? 'has-error' : ''); ?>>
                            <input class="form-control"
                                   type="email"
                                   name="email"
                                   value="<?php echo e(old('email')); ?>"
                                   placeholder="Ingresa tu email">
                            <?php echo $errors->first('email','<span class="help-block">:message</span>'); ?>

                        </div>
                        <div class="form-group" <?php echo e($errors->has('password') ? 'has-error' : ''); ?>>
                            <input class="form-control"
                                   type="password"
                                   name="password"
                                   placeholder="Ingresa tu contraseña">
                            <?php echo $errors->first('password','<span class="help-block">:message</span>'); ?>

                        </div>
                        <input type="hidden" id="peticion" name="peticion" value="pc">
                        <button class="btn btn-primary btn-block">Acceder</button>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <div class="row" style="position:absolute;
                            left:100px;
                            right:100px;
                            bottom:5px;
                            height:40px;
                            z-index:0;">
        <footer class="page-footer font-small blue">
            <div class="footer-copyright text-center text-danger">
                <code>© 2020 jcMorales - v. Berlín</code>
            </div>
        </footer>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Proyectos\INATEL\Back\solicitudes\resources\views/login.blade.php ENDPATH**/ ?>