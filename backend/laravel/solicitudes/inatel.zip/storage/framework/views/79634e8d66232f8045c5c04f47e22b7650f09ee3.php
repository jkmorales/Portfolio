<div class="form-inline">
    <div class="form-group form-inline col-md-4">
        <?php echo Form::label('name', 'Nombre(s)'); ?>

        <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group form-inline col-md-4">
        <?php echo Form::label('paterno', 'Apellido Paterno'); ?>

        <?php echo Form::text('paterno', null, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group form-inline col-md-4">
        <?php echo Form::label('materno', 'Apellido Materno'); ?>

        <?php echo Form::text('materno', null, ['class' => 'form-control']); ?>

    </div>
</div>
<br>
<hr>
</br>

<div class="form-group">
    <?php echo Form::label('email', 'Email'); ?>

    <?php echo Form::text('email', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('password', 'Contraseña'); ?>

    <?php echo Form::text('pass_word',  null, ['class' => 'form-control']); ?>

</div>

</br>
<div class="form-inline">
    <div class="form-group form-inline col-md-6">
        <?php echo Form::label('fkPerfil', 'Perfil'); ?>

        <?php echo Form::select('fkPerfil', [  1 => 'Ninja - Administrador',
                                        2 => 'Project Managment',
                                        3 => 'Team Leader',
                                        4 => 'Tesorero'
                                    ], null,['placeholder' => 'Elige un Perfil', 'class' => 'form-control']); ?>

    </div>
    <div class="form-group form-inline col-md-6">
        <?php echo Form::label('fkRecordStatus', 'Estatus'); ?>

        <?php echo Form::select('pkRecordStatus',[ 1 => 'Activo',
                                            2 => 'Pausado',
                                            3 => 'Eliminado'] , null,
                        ['placeholder' => 'Elige un Estatus', 'class' => 'form-control']); ?>

    </div>
</div>

<br>
<br>
</br>
<div class="form-inline">
    <div class="form-group form-inline col-md-12">
        <?php echo Form::label('file', 'Fotografía'); ?>

        <?php echo Form::file('picture_path'); ?>

    </div>
</div>

<br><br><br><br><br>
<div class="form-group">
    <?php echo Form::submit('ENVIAR', ['class' => 'btn btn-primary']); ?>

</div>
<?php /**PATH C:\Proyectos\INATEL\Back\solicitudes\resources\views/users/fragment/form.blade.php ENDPATH**/ ?>