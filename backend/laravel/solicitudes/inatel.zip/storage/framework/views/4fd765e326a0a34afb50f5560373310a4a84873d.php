<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
        <h2>
            Editar Usuario
            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary pull-right btn-sm">Todos los Usuarios</a>
        </h2>

        <?php echo $__env->make('users.fragment.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo Form::model($user,['route' => ['users.update', $user->id], 'method' => 'PUT', 'files' => true]); ?>


            <?php echo $__env->make('users.fragment.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo Form::close(); ?>

    </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Proyectos\INATEL\Back\solicitudes\resources\views/users/edit.blade.php ENDPATH**/ ?>