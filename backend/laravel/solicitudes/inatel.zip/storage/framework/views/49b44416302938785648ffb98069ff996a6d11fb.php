<p class="alert alert-info">
    Desde aquí podemos crear, eliminar, listar y editar a los usuarios.
</p><?php /**PATH C:\Proyectos\INATEL\Back\solicitudes\resources\views/users/fragment/aside.blade.php ENDPATH**/ ?>