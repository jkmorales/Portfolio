<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h1>
                        Listado de usuarios

                        <a href="<?php echo e(route('users.create')); ?>" class="btn btn-sm btn-primary pull-right">Nuevo</a>

                    </h1>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <button class="btn btn-sm btn-danger ">Cerrar Sesión</button>
                    </form>

                </div>
            </div>

            <div class="panel-body">
                <?php echo $__env->make('users.fragment.info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <table class="table table-striped table-hover">
                    <thead>
                    <tr>
                        <th width="20px">#</th>
                        <th> Usuario </th>
                        <th> E-mail </th>
                        <th> Perfil </th>
                        <th> Status </th>
                        <th> Borrar </th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td>
                                <strong>
                                    <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-link" title="Editar">
                                        <?php echo e($user->name); ?> <?php echo e($user->paterno); ?> <?php echo e($user->materno); ?>

                                    </a>
                                </strong>
                            </td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->perfil); ?></td>
                            <td><?php echo e($user->recordStatus); ?></td>
                            <td>
                                <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="_method" value="DELETE">
                                    <button class="btn btn-link"> <i class="fas fa-trash-alt" title="Eliminar"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo $users->render(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Proyectos\INATEL\Back\solicitudes\resources\views/index.blade.php ENDPATH**/ ?>