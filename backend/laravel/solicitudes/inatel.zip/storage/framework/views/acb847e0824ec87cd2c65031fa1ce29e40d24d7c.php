<?php $__env->startSection('content'); ?>
    <div class="col-sm-8">
        <h2>
            Nombre: <?php echo e($user->name); ?> <?php echo e($user->paterno); ?> <?php echo e($user->materno); ?>

            <hr>
            Email: <?php echo e($user->email); ?>

            <hr>
            Perfil: <?php echo e($user->perfil); ?>

            <hr>
            Estatus: <?php echo e($user->recordStatus); ?>

        </h2>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Proyectos\INATEL\Back\solicitudes\resources\views/users/show.blade.php ENDPATH**/ ?>